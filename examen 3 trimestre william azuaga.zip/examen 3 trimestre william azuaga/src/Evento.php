<?php

class Evento extends Conexion
{

  private $descripcion;

  function __construct()
  {

  }

   public function listarEventos()
   {
      $consulta="SELECT * FROM proyecto";
      $resultado=$this->conexion->query($consulta);
      return $resultado;
    }
}

 ?>
